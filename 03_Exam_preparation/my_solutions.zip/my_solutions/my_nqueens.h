
#ifndef N_QUEENS
# define N_QUEENS

#include <stdio.h>
#include <stdlib.h>

void	find_solution(int x);

#endif
