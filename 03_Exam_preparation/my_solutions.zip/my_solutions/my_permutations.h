
#ifndef PERMUTATIONS_H
# define PERMUTATIONS_H

#include <stdio.h>
#include <stdlib.h>

void	permute(char *str, int left);

#endif
