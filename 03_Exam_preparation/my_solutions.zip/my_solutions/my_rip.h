
#ifndef RIP_H
# define RIP_H

#include <stdio.h>

void	permute(char *str, int i, int rem_l, int rem_r, int open);

#endif
