
#ifndef POWERSET_H
# define POWERSET_H

#include <stdio.h>
#include <stdlib.h>

void	find_subsets(int idx, int target_sum, int current_sum, int subset[], int subset_len);

#endif
